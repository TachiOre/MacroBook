import unittest
from dataclasses import replace
from designer import Inputs, calculate
from design_modes import solve, convert_flow, MODES, TARGETS

class ModeTests(unittest.TestCase):
    def test_conversion_density_and_roundtrip(self):
        self.assertAlmostEqual(convert_flow(60,'L/min','kg/s',998),.998)
        for rho in (800,998,1200):
            self.assertAlmostEqual(convert_flow(convert_flow(5,'kg/s','L/min',rho),'L/min','kg/s',rho),5)
    def test_cold_flow_recovers_known_flow(self):
        p=Inputs()
        target=calculate(p)['results']['入力寸法の高温出口 [°C]']
        solved,r=solve(replace(p,hot_target=target,cold_flow=99),MODES[1])
        self.assertAlmostEqual(solved.cold_flow,p.cold_flow,places=8)
        self.assertAlmostEqual(r['results']['入力寸法の高温出口 [°C]'],target,places=8)
    def test_cold_flow_heating_target(self):
        p=Inputs();target=calculate(p)['results']['入力寸法の低温出口 [°C]']
        solved,r=solve(replace(p,cold_target=target),MODES[1],TARGETS[1])
        self.assertAlmostEqual(solved.cold_flow,p.cold_flow,places=8)
    def test_heating_area_matches_target(self):
        p=replace(Inputs(),margin=0,cold_target=45)
        solved,r=solve(p,MODES[0],TARGETS[1])
        self.assertAlmostEqual(r['design']['cold_out'],45,places=8)
        _,rr=solve(replace(solved,length=r['design']['length']),MODES[2])
        self.assertAlmostEqual(rr['results']['入力寸法の低温出口 [°C]'],45,places=8)
    def test_rating_ignores_impossible_target(self):
        p=replace(Inputs(),hot_target=-100,cold_target=1000)
        _,r=solve(p,MODES[2])
        self.assertAlmostEqual(r['results']['入力寸法の高温出口 [°C]'],51.471589360272375)
    def test_unreachable_flow(self):
        with self.assertRaisesRegex(ValueError,'冷却水量を増やしても'):
            solve(replace(Inputs(),hot_target=21),MODES[1])
    def test_invalid_heating_target(self):
        with self.assertRaises(ValueError):solve(replace(Inputs(),cold_target=90),MODES[0],TARGETS[1])
    def test_input_unchanged(self):
        p=Inputs();before=repr(p);solve(p,MODES[1]);self.assertEqual(repr(p),before)
    def test_invalid_density(self):
        with self.assertRaises(ValueError):convert_flow(1,'kg/s','L/min',0)

if __name__=='__main__':unittest.main()
