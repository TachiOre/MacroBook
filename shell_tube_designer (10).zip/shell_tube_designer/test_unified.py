import unittest
from dataclasses import replace,asdict
from designer import Inputs
from design_modes import MODES,TARGETS,solve
from unified_design import COUNT_MODE,solve_and_apply

class UnifiedTests(unittest.TestCase):
    def test_length_applied_without_changing_fixed_inputs(self):
        original=replace(Inputs(),margin=0)
        p,r,updates=solve_and_apply(original,MODES[0],TARGETS[0])
        self.assertEqual(set(updates),{'length'})
        self.assertAlmostEqual(r['results']['入力寸法の高温出口 [°C]'],original.hot_target)
        for key in ('tubes','hot_flow','cold_flow','inner_mm','outer_mm'):self.assertEqual(getattr(p,key),getattr(original,key))
        self.assertEqual(original.length,3)
    def test_heating_length_applied(self):
        p,r,updates=solve_and_apply(replace(Inputs(),tube_cold=1,margin=0),MODES[0],TARGETS[1])
        self.assertAlmostEqual(r['results']['入力寸法の低温出口 [°C]'],40,places=8)
        self.assertAlmostEqual(p.length,updates['length'])
    def test_count_keeps_length_and_meets_conditions(self):
        p,r,updates=solve_and_apply(Inputs(),COUNT_MODE,TARGETS[0])
        self.assertEqual(set(updates),{'tubes'})
        self.assertEqual(p.length,3)
        self.assertTrue(r['meets_design_area'])
        self.assertLessEqual(r['results']['入力寸法の管内圧損 [kPa]'],50)
        self.assertEqual(r['design']['length'],p.length)
        for n in range(1,int(p.tubes)):
            try:_,rr=solve(replace(Inputs(),tubes=n),MODES[0],TARGETS[0])
            except ValueError:continue
            self.assertFalse(rr['meets_design_area'] and rr['results']['入力寸法の管内圧損 [kPa]']<=50)
    def test_flow_updates_only_media(self):
        original=Inputs();p,r,updates=solve_and_apply(original,MODES[1],TARGETS[0])
        self.assertEqual(set(updates),{'cold_flow'})
        self.assertEqual(p.length,original.length)
        self.assertAlmostEqual(r['results']['入力寸法の高温出口 [°C]'],60)
    def test_rating_updates_outlets_only(self):
        p,r,updates=solve_and_apply(Inputs(),MODES[2],TARGETS[0])
        self.assertEqual(set(updates),{'hot_target','cold_target'})
        self.assertAlmostEqual(updates['hot_target'],r['results']['入力寸法の高温出口 [°C]'])
    def test_heating_shortage_explains_derived_outlet(self):
        p=replace(Inputs(),hot_in=82,cold_in=60,cold_target=80,hot_flow=500/60,cold_flow=10,tube_cold=1)
        for mode in (MODES[0],COUNT_MODE):
            with self.assertRaisesRegex(ValueError,'入力値ではありません'):
                solve_and_apply(p,mode,TARGETS[1])
    def test_unused_hot_target_does_not_block_heating(self):
        p=replace(Inputs(),hot_in=82,cold_in=60,cold_target=80,hot_target=-999,hot_flow=20,cold_flow=10,tube_cold=1)
        _,r,_=solve_and_apply(p,MODES[0],TARGETS[1])
        self.assertTrue(r['meets_target'])
    def test_impossible_count(self):
        with self.assertRaises(ValueError):solve_and_apply(replace(Inputs(),length=.0001),COUNT_MODE,TARGETS[0])

if __name__=='__main__':unittest.main()
