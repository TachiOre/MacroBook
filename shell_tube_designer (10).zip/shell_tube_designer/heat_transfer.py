"""伝熱式の関数モジュール。SI単位、温度差はK。GUIへの依存なし。"""
import math


def heat_duty(mass_flow, cp, inlet, outlet):
    """Q=m cp ΔT [W]。高温流体が放出する熱を正とする。

    種別：理論式・エネルギー収支
    参照サイト：https://handbook.ashrae.org/Handbooks/F25/SI/f25_ch04/f25_ch04_si.aspx（Heat Exchangers / NTU-Effectiveness）
    """
    return mass_flow * cp * (inlet - outlet)


def outlet_temperatures(q, hot_in, cold_in, ch, cc):
    """定常・外部放熱なしの両側エネルギー収支。

    種別：理論式・エネルギー収支
    参照サイト：https://ht.readthedocs.io/en/stable/ht.hx.html#ht.hx.effectiveness_from_NTU
    """
    return hot_in - q / ch, cold_in + q / cc


def tube_velocity(mass_flow, rho, inner_diameter, total_tubes, passes=1):
    """1パスの並列本数は総管本数/passes。径はm。

    種別：連続の式と円の面積から導出
    参照サイト：https://fluids.readthedocs.io/fluids.friction.html#fluids.friction.one_phase_dP
    """
    return mass_flow / (rho * (total_tubes / passes) * math.pi * inner_diameter**2 / 4)


def reynolds(rho, velocity, diameter, viscosity):
    """Re=ρvd/μ。粘度はPa s（動粘度ではない）。

    種別：無次元数の定義
    参照サイト：https://fluids.readthedocs.io/fluids.core.html#fluids.core.Reynolds
    """
    return rho * velocity * diameter / viscosity


def prandtl(cp, viscosity, conductivity):
    """Pr=cp μ/k。

    種別：無次元数の定義
    参照サイト：https://fluids.readthedocs.io/fluids.core.html#fluids.core.Prandtl
    """
    return cp * viscosity / conductivity


def darcy_friction(re):
    """平滑円管。遷移域は拒否。Darcy係数はFanning係数の4倍。

    種別：層流は理論式、乱流はPetukhov実験相関
    参照サイト：https://fluids.readthedocs.io/fluids.friction.html#fluids.friction.friction_laminar ; https://research.birmingham.ac.uk/files/259502772/LiuQ2025Comparative.pdf（式18の直後のf）
    """
    if re <= 0:
        raise ValueError('Reは正の値が必要です。')
    if re < 2300:
        return 64 / re
    if re < 3000 or re > 5e6:
        raise ValueError('遷移域または摩擦係数の採用範囲外です。')
    return (0.79 * math.log(re) - 1.64) ** -2


def nusselt(re, pr):
    """発達層流（壁温一定）またはGnielinski乱流相関。

    種別：層流は理論解、乱流はGnielinski実験相関
    参照サイト：https://ht.readthedocs.io/en/latest/ht.conv_internal.html#ht.conv_internal.laminar_T_const ; https://ht.readthedocs.io/en/latest/ht.conv_internal.html#ht.conv_internal.turbulent_Gnielinski
    """
    if re <= 0 or pr <= 0:
        raise ValueError('ReとPrは正の値が必要です。')
    if re < 2300:
        return 3.66
    if re < 3000:
        raise ValueError(f'Re={re:.0f}：遷移域2300～3000は計算対象外です。')
    if not 0.5 < pr <= 2000 or re > 5e6:
        raise ValueError('Gnielinski相関の適用範囲外です。')
    f = darcy_friction(re)
    return (f/8)*(re-1000)*pr / (1+12.7*math.sqrt(f/8)*(pr**(2/3)-1))


def tube_h(nu, conductivity, inner_diameter):
    """hi=Nu k/di [W/(m² K)]。

    種別：Nusselt数の定義から導出
    参照サイト：https://fluids.readthedocs.io/fluids.core.html#fluids.core.Nusselt
    """
    return nu * conductivity / inner_diameter


def overall_coefficient(di, do, hi, ho, wall_k, fouling_i, fouling_o):
    """管外面積基準Uo。各抵抗[m² K/W]も返す。

    種別：円筒熱伝導＋直列熱抵抗、汚れ項を外面基準に換算
    参照サイト：https://ht.readthedocs.io/en/latest/ht.conduction.html#ht.conduction.cylindrical_heat_transfer ; https://handbook.ashrae.org/Handbooks/F25/SI/f25_ch04/f25_ch04_si.aspx（Combined Heat Transfer）
    """
    resistance = {'管内対流': do/(di*hi), '管内汚れ': do/di*fouling_i,
                  '管壁': do*math.log(do/di)/(2*wall_k),
                  '管外汚れ': fouling_o, 'シェル側対流': 1/ho}
    return 1/sum(resistance.values()), resistance


def effectiveness(ntu, cr):
    """直管1管パス・理想対向流のε。Cr=1の極限も処理。

    種別：理想対向流の理論式
    参照サイト：https://ht.readthedocs.io/en/stable/ht.hx.html#ht.hx.effectiveness_from_NTU
    """
    if not 0 <= cr <= 1 or ntu < 0:
        raise ValueError('0≤Cr≤1、NTU≥0が必要です。')
    if cr == 1:
        return ntu / (1 + ntu)
    z = -math.expm1(-ntu * (1-cr))
    return z / ((1-cr) + cr*z)


def required_ntu(eps, cr):
    """理想対向流の逆算。ε=1は無限面積が必要。

    種別：対向流ε式の代数的逆算
    参照サイト：https://ht.readthedocs.io/en/stable/ht.hx.html#ht.hx.NTU_from_effectiveness
    """
    if not 0 <= cr <= 1 or not 0 < eps < 1:
        raise ValueError('対向流では0≤Cr≤1、0<目標ε<1が必要です。')
    if cr == 1:
        return eps / (1-eps)
    return math.log1p(eps*(1-cr)/(1-eps)) / (1-cr)


def lmtd(a, b):
    """端部温度差a,bの対数平均。等温度差の極限も処理。

    種別：物性・U一定の理論式
    参照サイト：https://handbook.ashrae.org/Handbooks/F25/SI/f25_ch04/f25_ch04_si.aspx（Mean Temperature Difference Analysis、式43–44）
    """
    if a <= 0 or b <= 0:
        raise ValueError('端部温度差は正の値が必要です。')
    if abs(a-b) < 1e-9*max(a,b):
        return (a+b)/2
    return (a-b)/math.log(a/b)


def outer_area(total_tubes, outer_diameter, length):
    """全管の外面積[m²]。パス数を二重に掛けない。

    種別：円筒外面積の幾何式、総管本数分を加算
    参照サイト：https://ht.readthedocs.io/en/latest/ht.conduction.html#ht.conduction.cylindrical_heat_transfer
    """
    return total_tubes * math.pi * outer_diameter * length


def required_area(ntu, cmin, u, margin_percent=0):
    """指定余裕率を含む必要面積[m²]。

    種別：NTU定義から導出、余裕率はユーザー指定
    参照サイト：https://ht.readthedocs.io/en/stable/ht.hx.html#ht.hx.NTU_from_UA
    """
    return ntu*cmin/u*(1+margin_percent/100)


def required_length(area, total_tubes, outer_diameter):
    """1本あたりの有効管長[m]。

    種別：Ao=NπdoLの代数的逆算
    参照サイト：https://ht.readthedocs.io/en/latest/ht.conduction.html#ht.conduction.cylindrical_heat_transfer
    """
    return area / (math.pi*outer_diameter*total_tubes)


def tube_pressure_drop(f, length, diameter, rho, velocity, minor_k, passes=1):
    """Darcy–Weisbach＋局所損失[Pa]。流路長はpasses×length。

    種別：Darcy–Weisbach式＋局所損失係数の定義
    参照サイト：https://fluids.readthedocs.io/fluids.friction.html#fluids.friction.one_phase_dP ; https://fluids.readthedocs.io/fluids.core.html#fluids.core.dP_from_K
    """
    return (f*passes*length/diameter+minor_k)*rho*velocity**2/2
