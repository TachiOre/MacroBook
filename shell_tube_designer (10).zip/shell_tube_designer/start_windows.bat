@echo off
cd /d "%~dp0"
python designer.py
pause
