"""画面の色と、①・②・反映操作の説明。計算モデルには依存しない。"""
PALETTE={'input':('#e8f2ff','#174a8b'),'assumed':('#fff3ce','#805500'), 'geometry':('#f0e8ff','#6538a0'),'output':('#e4f5ea','#17643c'),'unused':('#eeeeee','#777777')}

def comparison_rows(p,result):
    """仮定・候補・推算の段階を混同しない比較表示。"""
    b=result.get('preliminary',{})
    if result.get('stage')=='preliminary':
        return [('① 仮定U',f'{p.assumed_u:.5g} W/(m² K)','②で推算','assumed'),('① 必要面積',f'{b["design_area"]:.5g} m²（余裕込み）','②で再評価','assumed'),('管本数・有効管長','未定','②で寸法候補を選ぶ','geometry')]
    r=result['results'];d=result['design']
    rows=[]
    if b:
        rows.extend([('総括伝熱係数U',f'① 仮定 {p.assumed_u:.5g}',f'② 推算 {r["外面基準Uo [W/(m² K)]"]:.5g} W/(m² K)','output'),('伝熱面積',f'① 仮定U：{b["design_area"]:.5g}',f'② 推算U：{d["area"]:.5g} m²（余裕込み）','output')])
    rows.extend([('管本数',f'候補 {int(p.tubes)} 本',f'反映する本数 {int(p.tubes)} 本','geometry'),('有効管長',f'候補 {p.length:.5g} m',f'推算Uの必要管長 {d["length"]:.5g} m','output'),('高温出口',f'候補 {r["入力寸法の高温出口 [°C]"]:.5g} ℃',f'必要寸法 {d["hot_out"]:.5g} ℃','output'),('低温出口',f'候補 {r["入力寸法の低温出口 [°C]"]:.5g} ℃',f'必要寸法 {d["cold_out"]:.5g} ℃','output')])
    return rows
