"""Shell & tube preliminary thermal designer. Python 3.10+, Matplotlib + Tkinter.
Single-phase, constant properties; straight tubes / 1 tube pass / counterflow; tube-side hot fluid.
Run: python designer.py   or   python designer.py --demo
"""
from dataclasses import dataclass, asdict, fields
from design_modes import MODES, TARGETS, solve, convert_flow
from ui_guidance import PALETTE, comparison_rows
import math
import json
import sys

@dataclass
class Inputs:
    hot_in: float = 80.0
    hot_target: float = 60.0
    cold_in: float = 20.0
    cold_target: float = 40.0
    cold_rho: float = 998.0
    cold_mu: float = 0.000653
    cold_k: float = 0.630
    assumed_u: float = 600.0
    tube_cold: float = 0.0
    geometry_choice: float = 0.0
    hot_flow: float = 1.0
    cold_flow: float = 1.2
    hot_cp: float = 4180.0
    cold_cp: float = 4180.0
    hot_rho: float = 978.0
    hot_mu: float = 0.000404
    hot_k: float = 0.664
    shell_h: float = 1500.0
    outer_mm: float = 19.0
    inner_mm: float = 16.0
    tubes: float = 40.0
    length: float = 3.0
    wall_k: float = 16.0
    fouling_i: float = 0.0001
    fouling_o: float = 0.0001
    margin: float = 15.0
    minor_k: float = 3.0
    allowable_dp: float = 50.0
    shell_mm: float = 250.0
    pitch_mm: float = 25.0

LABELS = {
'assumed_u': ('① 総括伝熱係数Uの仮定値', 'W/(m² K)'),
'cold_mu': ('低温側 粘度', 'Pa s'), 'cold_k': ('低温側 熱伝導率', 'W/(m K)'),
'hot_in': ('高温側入口', '°C'), 'hot_target': ('高温側 目標出口', '°C'),
'cold_in': ('低温側入口', '°C'),
'cold_target': ('低温側 加熱目標出口', '°C'),
'cold_rho': ('低温側 密度', 'kg/m³'), 'hot_flow': ('高温側 質量流量', 'kg/s'),
'cold_flow': ('低温側 質量流量', 'kg/s'), 'hot_cp': ('高温側 比熱', 'J/(kg K)'),
'cold_cp': ('低温側 比熱', 'J/(kg K)'), 'hot_rho': ('高温側 密度', 'kg/m³'),
'hot_mu': ('高温側 粘度', 'Pa s'), 'hot_k': ('高温側 熱伝導率', 'W/(m K)'),
'shell_h': ('シェル側伝熱係数【仮定】', 'W/(m² K)'),
'outer_mm': ('管外径', 'mm'), 'inner_mm': ('管内径', 'mm'),
 'tubes': ('総管本数', '本'), 'length': ('1本の有効管長', 'm'),
'wall_k': ('管壁 熱伝導率', 'W/(m K)'),
'fouling_i': ('管内 汚れ抵抗（内面基準）', 'm² K/W'),
'fouling_o': ('管外 汚れ抵抗（外面基準）', 'm² K/W'),
'margin': ('必要面積の余裕率', '%'), 'minor_k': ('入口・出口 合計K', '−'),
'allowable_dp': ('管内 許容圧力損失', 'kPa'),
'shell_mm': ('シェル内径（収容概算用）', 'mm'), 'pitch_mm': ('管ピッチ（正方配列）', 'mm')}


from heat_transfer import (heat_duty, outlet_temperatures, tube_velocity, reynolds,
    prandtl, darcy_friction, nusselt, tube_h, overall_coefficient,
    effectiveness, required_ntu, lmtd, outer_area, required_area, required_length,
    tube_pressure_drop)

def calculate(p):
    """Thermal design + existing-geometry rating. All internal lengths in metres."""
    for f in fields(p):
        if not math.isfinite(getattr(p, f.name)):
            raise ValueError(f'{f.name}: 有限の数値を入力してください。')
    for key in ('hot_flow','cold_flow','hot_cp','cold_cp','hot_rho','hot_mu','hot_k',
                'shell_h','outer_mm','inner_mm','length','wall_k','allowable_dp','shell_mm','pitch_mm'):
        if getattr(p, key) <= 0:
            raise ValueError(f'{LABELS[key][0]}は正の値が必要です。')
    for key in ('fouling_i','fouling_o','margin','minor_k'):
        if getattr(p, key) < 0:
            raise ValueError(f'{LABELS[key][0]}は0以上が必要です。')
    if p.tubes < 1 or p.tubes > 2000 or p.tubes != int(p.tubes):
        raise ValueError('管本数は1～2000の整数にしてください。')
    if not p.cold_in < p.hot_target < p.hot_in:
        raise ValueError('低温入口 < 高温目標出口 < 高温入口 が必要です。')
    if not p.inner_mm < p.outer_mm < p.pitch_mm < p.shell_mm:
        raise ValueError('管内径 < 管外径 < 管ピッチ < シェル内径 が必要です。')
    di, do = p.inner_mm / 1000, p.outer_mm / 1000
    passes, n = 1, int(p.tubes)
    if p.tube_cold not in (0,1): raise ValueError('管内流体の指定が不正です。')
    mass,rho,mu,cp,k = (p.cold_flow,p.cold_rho,p.cold_mu,p.cold_cp,p.cold_k) if p.tube_cold else (p.hot_flow,p.hot_rho,p.hot_mu,p.hot_cp,p.hot_k)
    if min(mass,rho,mu,cp,k)<=0:raise ValueError('管内側の物性と流量は正の値が必要です。')
    velocity = tube_velocity(mass, rho, di, n, passes)
    re = reynolds(rho, velocity, di, mu)
    pr = prandtl(cp, mu, k)
    notes = ['直管1管パス・理想対向流・折返しなし。単相・物性一定・外部放熱なし。'+('低温側は管内（加熱）、高温側はシェル側。' if p.tube_cold else '高温側は管内（冷却）、低温側はシェル側。'),
             'シェル側hは入力値。バッフル漏れ・バイパス・窓部・シェル側圧損は未計算。']
    if re < 2300:
        nu, friction = nusselt(re, pr), darcy_friction(re)
        notes.append('層流：Nu=3.66（十分発達した円管・壁温一定）。入口助走区間の補正は未実装。')
        if p.length / di < max(0.05 * re, 0.05 * re * pr):
            notes.append('注意：助走区間が管長に対して長く、層流の発達流仮定が成立しない可能性。')
    elif re < 3000:
        raise ValueError(f'Re={re:.0f}：遷移域2300～3000は相関の不確かさが大きいため計算対象外です。')
    else:
        if not 0.5 < pr <= 2000 or re > 5e6:
            raise ValueError('Gnielinski相関の適用範囲外（Pr>0.5かつ≤2000、Re≤5e6）。')
        friction = darcy_friction(re)
        nu = nusselt(re, pr)
        notes.append('乱流：Gnielinski相関＋平滑管のDarcy摩擦係数。粗さ・粘度の壁温補正なし。')
    hi = tube_h(nu, k, di)
    u, resistance = overall_coefficient(di, do, hi, p.shell_h, p.wall_k, p.fouling_i, p.fouling_o)
    ch, cc = p.hot_flow * p.hot_cp, p.cold_flow * p.cold_cp
    cmin, cmax = min(ch, cc), max(ch, cc)
    cr = cmin / cmax
    q = heat_duty(p.hot_flow, p.hot_cp, p.hot_in, p.hot_target)
    _, co = outlet_temperatures(q, p.hot_in, p.cold_in, ch, cc)
    eps_req = q / (cmin * (p.hot_in - p.cold_in))
    ntu_req = required_ntu(eps_req, cr)
    ua_req = ntu_req * cmin
    area_req = required_area(ntu_req, cmin, u)
    area_design = required_area(ntu_req, cmin, u, p.margin)
    length_req = required_length(area_design, n, do)
    delta = lmtd(p.hot_in - co, p.hot_target - p.cold_in)
    correction = q / (ua_req * delta)
    area = outer_area(n, do, p.length)
    eps = effectiveness(u * area / cmin, cr)
    q_actual = eps * cmin * (p.hot_in - p.cold_in)
    dp = tube_pressure_drop(friction, p.length, di, rho, velocity, p.minor_k, passes)
    dp_design = tube_pressure_drop(friction, length_req, di, rho, velocity, p.minor_k, passes)
    # Infinite square-lattice estimate; not a tube layout or mechanical guarantee.
    packing = n * (p.pitch_mm / 1000)**2 / (math.pi * (p.shell_mm / 1000)**2 / 4)
    if packing > 1:
        notes.append('注意：管ピッチ×本数の占有面積がシェル断面を超えます。配置を再検討してください。')
    else:
        notes.append('管収容は面積比のみの概算。管板端部・管束隙間を含む実配置は別途確認。')
    if correction < 0.75:
        notes.append('注意：LMTD補正係数F<0.75。パス構成・流量の見直しを検討してください。')
    if dp_design / 1000 > p.allowable_dp:
        notes.append('注意：必要管長での管内圧損が許容値を超えます。')
    if p.length / di < 10:
        notes.append('注意：L/di<10。短管の入口効果を別途検討してください。')
    th_out, tc_out = outlet_temperatures(q_actual, p.hot_in, p.cold_in, ch, cc)
    results = {
      '目標交換熱量 [kW]': q / 1000, '目標時 低温出口 [°C]': co,
      '管内流速 [m/s]': velocity, '管内Re [-]': re, '管内Pr [-]': pr,
      '管内Nu [-]': nu, '管内hi [W/(m² K)]': hi, '外面基準Uo [W/(m² K)]': u,
      '目標時 LMTD [K]': delta, '目標時 補正係数F [-]': correction,
      '必要面積（余裕なし） [m²]': area_req, '設計面積（余裕込み） [m²]': area_design,
      '必要有効管長（余裕込み） [m]': length_req, '入力寸法の面積 [m²]': area,
      '入力寸法の交換熱量 [kW]': q_actual / 1000,
      '入力寸法の高温出口 [°C]': th_out,
      '入力寸法の低温出口 [°C]': tc_out,
      '入力寸法の管内圧損 [kPa]': dp / 1000,
      '必要管長の管内圧損 [kPa]': dp_design / 1000,
      '管束占有面積比（概算） [-]': packing,
    }
    return {'results': results, 'resistance': resistance, 'notes': notes,
            'design': {'hot_out': outlet_temperatures(effectiveness(u*area_design/cmin, cr)*cmin*(p.hot_in-p.cold_in), p.hot_in, p.cold_in, ch, cc)[0],
                       'cold_out': outlet_temperatures(effectiveness(u*area_design/cmin, cr)*cmin*(p.hot_in-p.cold_in), p.hot_in, p.cold_in, ch, cc)[1],
                       'length': length_req, 'area': area_design},
            'meets_target': q_actual >= q * (1 - 1e-10),
            'meets_design_area': area >= area_design * (1 - 1e-10)}

FORMULAS = '''計算の流れ（詳しくはREADME_ja.md）
1. Q = m_h cp_h (T_hi − T_ho)
   低温出口 T_co = T_ci + Q/(m_c cp_c)
2. 全N本が並列。v = m_h/[ρ N π di²/4]
   Re = ρvdi/μ、Pr = cpμ/k、hi = Nu k/di
3. 層流：Nu=3.66、Darcy f=64/Re
   乱流：f=(0.79 ln Re−1.64)⁻²
   Nu=(f/8)(Re−1000)Pr/[1+12.7√(f/8)(Pr^(2/3)−1)]
4. 外面基準の総括伝熱係数：
   1/Uo = do/(di hi) + (do/di)Rf_i
          + do ln(do/di)/(2kw) + Rf_o + 1/ho
5. Ch=m_h cp_h、Cc=m_c cp_c、Cr=Cmin/Cmax
   NTU=Uo Ao/Cmin
   ε=[1−exp(−NTU(1−Cr))]/[1−Cr exp(−NTU(1−Cr))]
   Cr=1では ε=NTU/(1+NTU)
   Q=ε Cmin (T_hi−T_ci)
6. 目標εから対向流のNTUを逆算：
   Ao_req=NTU_req Cmin/Uo
   Ao_design=Ao_req (1+余裕率/100)
   L_req=Ao_design/(π do N)
7. ΔT1=T_hi−T_co、ΔT2=T_ho−T_ci
   ΔTlm=(ΔT1−ΔT2)/ln(ΔT1/ΔT2)
   F=1（理想対向流）
8. 管内圧損：Δp=[f (L/di)+ΣK] ρv²/2

Lは1本の有効管長。Ao=NπdoLにはパス数を再乗算しない。
ΣKは入口・出口等の合計を入力。ノズル径は未考慮。
シェル側hoは仮定入力。シェル側圧損・機械強度は未計算。
温度依存物性、沸騰・凝縮、反応、非ニュートン流体は対象外。
'''


from pathlib import Path
FORMULAS += '\n\n加熱モードでは低温流体が管内、高温媒体がシェル側です。hi・Re・Pr・圧損は管内に選んだ流体の物性と流量を使います。現行GUIは求める出力を選択し、「計算して反映」で推算U・必要面積と選択出力を更新します。\n' + Path(__file__).with_name('式の参照サイト.md').read_text(encoding='utf-8')

def run_gui():
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog, font as tkfont
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    from visuals import temperature_figure, dimension_figure, resistance_figure
    from unified_design import UI_MODES,COUNT_MODE,solve_and_apply
    root=tk.Tk();root.title('直管・対向流 熱交換器｜条件を固定して計算・反映');root.geometry('1700x980')
    root.minsize(1280,740)
    available=set(tkfont.families(root))
    family=next((f for f in ('Yu Gothic UI','Meiryo','Noto Sans CJK JP') if f in available),'Arial')
    for name in ('TkDefaultFont','TkTextFont','TkMenuFont'):tkfont.nametofont(name).configure(family=family,size=10)
    style=ttk.Style(root);style.theme_use('clam')
    colors={'input':('#e8f2ff','#174a8b'),'output':('#e5f3e9','#17643c'),'changed':('#ffe1a8','#6b3900'),'unused':('#eeeeee','#777777')}
    for role,(bg,fg) in colors.items():
        style.configure(role+'.TEntry',fieldbackground=bg,foreground=fg)
        style.map(role+'.TEntry',fieldbackground=[('readonly',bg),('disabled',bg)],foreground=[('readonly',fg),('disabled',fg)])
        style.configure(role+'.TLabel',background=bg,foreground=fg,padding=3)
    style.configure('Compute.TButton',background='#ccebd8',foreground='#17643c',padding=12)
    ttk.Label(root,text='条件を入力 → 求める量を選択 →「計算して反映」',font=(family,18,'bold')).pack(anchor='w',padx=16,pady=(12,4))
    ttk.Label(root,text='入力中は計算しません。選んだ出力だけを書き換え、その他の有効な入力条件は保持します。').pack(anchor='w',padx=16)
    legend=ttk.Frame(root);legend.pack(fill='x',padx=16,pady=6)
    for role,label in [('input','青：固定する入力'),('output','緑：求める出力'),('changed','橙：今回の計算で値が変わったセル'),('unused','灰：使わない条件')]:ttk.Label(legend,text=label,style=role+'.TLabel').pack(side='left',padx=4)
    tabs=ttk.Notebook(root);tabs.pack(fill='both',expand=True,padx=12,pady=8)
    page=ttk.Frame(tabs);tabs.add(page,text='入力・計算結果')
    host=ttk.Frame(page);host.pack(side='left',fill='y')
    scroll=tk.Canvas(host,width=610,highlightthickness=0)
    bar=ttk.Scrollbar(host,orient='vertical',command=scroll.yview);bar.pack(side='right',fill='y');scroll.pack(side='left',fill='both',expand=True)
    scroll.configure(yscrollcommand=bar.set)
    left=ttk.Frame(scroll,padding=8);scroll.create_window((0,0),window=left,anchor='nw')
    left.bind('<Configure>',lambda e:scroll.configure(scrollregion=scroll.bbox('all')))
    right=ttk.Frame(page,padding=10);right.pack(side='left',fill='both',expand=True)
    mode=tk.StringVar(value=UI_MODES[0]);purpose=tk.StringVar(value='管内を冷却');target=tk.StringVar(value=TARGETS[0])
    for row,label,var,choices in [(0,'求める量（出力）',mode,UI_MODES),(1,'用途',purpose,('管内を冷却','管内を加熱')),(2,'目標温度を指定する側',target,TARGETS)]:
        ttk.Label(left,text=label).grid(row=row,column=0,sticky='w',pady=3)
        ttk.Combobox(left,textvariable=var,values=choices,state='readonly',width=34).grid(row=row,column=1,columnspan=3,sticky='w')
    role_note=ttk.Label(left,text='',wraplength=570);role_note.grid(row=3,column=0,columnspan=4,sticky='w',pady=8)
    variables={};entries={};labels={};units={};previous_units={};conversion_labels={}
    default=Inputs();visible={k:v for k,v in LABELS.items() if k!='assumed_u'}
    status=ttk.Label(right,text='未計算：条件を入力して「計算して反映」を押してください。',wraplength=730,font=(family,12,'bold'));status.pack(fill='x',pady=6)
    history=ttk.Treeview(right,columns=('field','before','after'),show='headings',height=4)
    for key,title,width in [('field','今回反映する項目',180),('before','変更前',140),('after','変更後',180)]:history.heading(key,text=title);history.column(key,width=width,minwidth=90)
    history.tag_configure('changed',background=colors['changed'][0],foreground=colors['changed'][1]);history.pack(fill='x',pady=6)
    result_panes=ttk.Panedwindow(right,orient='horizontal');result_panes.pack(fill='both',expand=True)
    numeric_frame=ttk.Frame(result_panes);graph_frame=ttk.Frame(result_panes)
    result_panes.add(numeric_frame,weight=1);result_panes.add(graph_frame,weight=1)
    ttk.Label(graph_frame,text='反映後の入口・出口温度（境界線をドラッグして横幅を変更できます）',wraplength=720).pack(anchor='w',padx=5,pady=3)
    output=tk.Text(numeric_frame,wrap='word',font=(family,10),padx=8,pady=8,height=9);output.pack(fill='both',expand=True)
    outbar=ttk.Scrollbar(output,command=output.yview);outbar.pack(side='right',fill='y');output.configure(yscrollcommand=outbar.set,state='disabled')
    for role,(bg,fg) in colors.items():output.tag_configure(role,background=bg,foreground=fg)
    plot_pages={'temperature':graph_frame};figures={}
    for key,title in [('dimensions','反映後の寸法図'),('resistance','伝熱の仕組み')]:
        frame=ttk.Frame(tabs);tabs.add(frame,text=title)
        ttk.Label(frame,text='「計算して反映」で更新します。寸法図の長さは有効管長で、胴・ヘッダーを含む全長ではありません。',wraplength=1300).pack(anchor='w',padx=10,pady=8)
        plot_pages[key]=frame
    def show_figure(key,fig):
        frame=plot_pages[key]
        for w in list(frame.winfo_children())[1:]:w.destroy()
        figures[key]=fig
        canvas=FigureCanvasTkAgg(fig,master=frame);canvas.draw();NavigationToolbar2Tk(canvas,frame).update();canvas.get_tk_widget().pack(fill='both',expand=True)
    flags={'dirty':True,'writing':False};cache={};field_roles={}
    def update_conversion(*args):
        for key,rho in [('hot_flow','hot_rho'),('cold_flow','cold_rho')]:
            if key not in conversion_labels or rho not in variables:continue
            try:
                other='L/min' if units[key].get()=='kg/s' else 'kg/s'
                value=convert_flow(float(variables[key].get()),units[key].get(),other,float(variables[rho].get()))
                conversion_labels[key].configure(text=f'= {value:.6g} {other}')
            except ValueError:conversion_labels[key].configure(text='換算待ち')
    def mark_dirty(*args):
        update_conversion()
        if flags['writing']:return
        flags['dirty']=True
        status.configure(text='条件が変更されています。結果は未更新です。「計算して反映」を押してください。')
    def switch_unit(key):
        rho='hot_rho' if key=='hot_flow' else 'cold_rho'
        try:
            value=convert_flow(float(variables[key].get()),previous_units[key],units[key].get(),float(variables[rho].get()))
            variables[key].set(f'{value:.12g}');previous_units[key]=units[key].get()
        except ValueError:units[key].set(previous_units[key])
        mark_dirty()
    for row,(key,(label,unit)) in enumerate(visible.items(),start=4):
        labels[key]=ttk.Label(left,text=label);labels[key].grid(row=row,column=0,sticky='w',pady=2)
        variables[key]=tk.StringVar(value=str(getattr(default,key)))
        entries[key]=ttk.Entry(left,textvariable=variables[key],width=12);entries[key].grid(row=row,column=1,padx=6)
        if key in ('hot_flow','cold_flow'):
            units[key]=tk.StringVar(value='kg/s');previous_units[key]='kg/s'
            box=ttk.Combobox(left,textvariable=units[key],values=('kg/s','L/min'),state='readonly',width=7);box.grid(row=row,column=2,sticky='w');box.bind('<<ComboboxSelected>>',lambda e,k=key:switch_unit(k))
            conversion_labels[key]=ttk.Label(left,text='');conversion_labels[key].grid(row=row,column=3,sticky='w')
        else:ttk.Label(left,text=unit).grid(row=row,column=2,columnspan=2,sticky='w')
        variables[key].trace_add('write',mark_dirty)
    def paint(key,role):
        entries[key].configure(style=role+'.TEntry');labels[key].configure(style=role+'.TLabel')
    def update_roles(*args):
        outputs={'length'} if mode.get()==MODES[0] else {'tubes'} if mode.get()==COUNT_MODE else {'hot_flow' if purpose.get()=='管内を加熱' else 'cold_flow'} if mode.get()==MODES[1] else {'hot_target','cold_target'}
        unused={'hot_mu','hot_k'} if purpose.get()=='管内を加熱' else {'cold_mu','cold_k'}
        if mode.get()!=MODES[2]:unused.add('cold_target' if target.get()==TARGETS[0] else 'hot_target')
        if mode.get() in (MODES[1],MODES[2]):unused.add('margin')
        for key in entries:
            role='output' if key in outputs else 'unused' if key in unused else 'input'
            field_roles[key]=role
            entries[key].configure(state='readonly' if role=='output' else 'disabled' if role=='unused' else 'normal');paint(key,role)
            labels[key].configure(text=visible[key][0]+('【出力】' if role=='output' else ''))
        if mode.get()==MODES[0]:text='固定：本数・管径・流量・目標温度 → 出力：必要有効管長と面積。'
        elif mode.get()==COUNT_MODE:text='固定：有効管長・管径・流量・目標温度 → 出力：目標と余裕面積・管内許容圧損を満たす最小本数（1～2000本）。'
        elif mode.get()==MODES[1]:text='固定：寸法・管内流量・目標温度 → 出力：シェル側媒体流量。'
        else:text='固定：寸法・両側流量・入口温度 → 出力：両側出口温度・交換熱量。'
        role_note.configure(text=text+' Uは管内相関式と入力hoから推算します。')
        mark_dirty()
    def change_purpose(*args):
        target.set(TARGETS[1] if purpose.get()=='管内を加熱' else TARGETS[0]);update_roles()
    mode.trace_add('write',update_roles);target.trace_add('write',update_roles);purpose.trace_add('write',change_purpose)
    update_roles()
    def compute():
        try:
            values={}
            for key,var in variables.items():
                if field_roles[key]=='input':values[key]=float(var.get())
                else:
                    try:values[key]=float(var.get())
                    except ValueError:values[key]=getattr(default,key)
                    if field_roles[key]=='unused':values[key]=getattr(default,key)
            for key,rho in [('hot_flow','hot_rho'),('cold_flow','cold_rho')]:values[key]=convert_flow(values[key],units[key].get(),'kg/s',values[rho])
            values.update(tube_cold=float(purpose.get()=='管内を加熱'),geometry_choice=2.0)
            original=Inputs(**values)
            resolved,result,updates=solve_and_apply(original,mode.get(),target.get())
            # 計算と全図の生成が成功してから入力セルを変更する。
            temp=temperature_figure(resolved,result,compact=True);drawing=dimension_figure(resolved,result);resistance=resistance_figure(bool(resolved.tube_cold))
            updates_display={}
            for key,value in updates.items():
                if key in units:value=convert_flow(value,'kg/s',units[key].get(),getattr(resolved,'hot_rho' if key=='hot_flow' else 'cold_rho'))
                updates_display[key]=value
            flags['writing']=True
            changes=[];history.delete(*history.get_children())
            for key,role in field_roles.items():paint(key,role)
            for key,value in updates_display.items():
                before=variables[key].get()
                try:changed=not math.isclose(float(before),value,rel_tol=1e-9,abs_tol=1e-9)
                except ValueError:changed=True
                after=f'{value:.12g}'
                variables[key].set(after)
                if changed:paint(key,'changed');changes.append((key,before,after))
                history.insert('', 'end',values=(visible[key][0],before,after),tags=('changed',) if changed else ())
            flags['writing']=False;flags['dirty']=False
            saved=asdict(original)
            # セルへ反映した出力を保存。目標温度入力は変更しない。
            for key,value in updates.items():saved[key]=value
            previous_results=cache.get('results',{}).copy()
            cache.clear();cache.update(inputs=saved,resolved_inputs=asdict(resolved),flow_units={k:v.get() for k,v in units.items()},**result)
            output.configure(state='normal');output.delete('1.0','end')
            for key,value in result['results'].items():
                changed=key in previous_results and not math.isclose(previous_results[key],value,rel_tol=1e-9,abs_tol=1e-9)
                output.insert('end',f'{key}：{value:,.6g}\n','changed' if changed else 'output')
            output.insert('end','\n仮定・適用条件\n'+'\n'.join(result['notes']))
            output.configure(state='disabled')
            show_figure('temperature',temp);show_figure('dimensions',drawing);show_figure('resistance',resistance)
            status.configure(text='計算・反映完了：'+('、'.join(visible[k][0] for k,_,_ in changes)+'を橙色で表示。' if changes else '出力の数値は前回と同じです。'))
            return True
        except (ValueError,OverflowError,ZeroDivisionError) as exc:
            flags['writing']=False;flags['dirty']=True
            status.configure(text='反映できません：'+str(exc));messagebox.showerror('計算エラー',str(exc));return False
    def ensure_current():
        if not cache or flags['dirty']:
            messagebox.showinfo('未計算','「計算して反映」を押して、現在の条件で結果を更新してください。');return False
        return True
    def save():
        if not ensure_current():return
        path=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('計算記録','*.json')])
        if path:
            try:Path(path).write_text(json.dumps(cache,ensure_ascii=False,indent=2),encoding='utf-8')
            except OSError as exc:messagebox.showerror('保存エラー',str(exc))
    def load():
        path=filedialog.askopenfilename(filetypes=[('計算記録','*.json')])
        if not path:return
        try:
            data=json.loads(Path(path).read_text(encoding='utf-8'));p=Inputs(**data['inputs'])
            selected=data.get('mode',UI_MODES[0]);selected=MODES[1] if selected=='冷却水量を求める' else selected
            if selected not in UI_MODES:selected=UI_MODES[0]
            flags['writing']=True
            purpose.set('管内を加熱' if p.tube_cold else '管内を冷却');mode.set(selected);target.set(data.get('target_side',TARGETS[int(p.tube_cold)]))
            for key,var in variables.items():var.set(str(getattr(p,key)))
            for key in units:
                unit=data.get('flow_units',{}).get(key,'kg/s');rho=p.hot_rho if key=='hot_flow' else p.cold_rho
                units[key].set(unit);previous_units[key]=unit
                variables[key].set(f'{convert_flow(getattr(p,key),"kg/s",unit,rho):.12g}')
            flags['writing']=False;mark_dirty()
            status.configure(text='条件を読み込みました。まだ計算・反映していません。')
        except (OSError,ValueError,KeyError,TypeError) as exc:
            flags['writing']=False;messagebox.showerror('読込エラー',str(exc))
    def export_png():
        if not ensure_current():return
        key='temperature' if tabs.select()==str(page) else next((k for k,v in plot_pages.items() if str(v)==tabs.select()),'dimensions')
        path=filedialog.asksaveasfilename(defaultextension='.png',filetypes=[('図','*.png')])
        if path:
            try:figures[key].savefig(path,dpi=160)
            except OSError as exc:messagebox.showerror('出力エラー',str(exc))
    actions=ttk.Frame(root,padding=8);actions.pack(fill='x',before=tabs)
    ttk.Button(actions,text='計算して反映',style='Compute.TButton',command=compute).pack(side='left',padx=6)
    ttk.Button(actions,text='反映済み寸法図を開く',command=lambda:tabs.select(plot_pages['dimensions']) if ensure_current() else None).pack(side='left',padx=6)
    ttk.Button(actions,text='PNG保存',command=export_png).pack(side='left',padx=6)
    ttk.Button(actions,text='JSON保存',command=save).pack(side='left',padx=6)
    ttk.Button(actions,text='条件を読み込む（計算しない）',command=load).pack(side='left',padx=6)
    formula=ttk.Frame(tabs);tabs.add(formula,text='式・出典')
    text=tk.Text(formula,wrap='word',font=(family,11),padx=16,pady=12);text.pack(fill='both',expand=True);text.insert('1.0',FORMULAS);text.configure(state='disabled')
    # 起動時・入力変更時・保存時は計算を実行しない。
    root.mainloop()

if __name__ == '__main__':
    if '--demo' in sys.argv:
        print(json.dumps(calculate(Inputs()), ensure_ascii=False, indent=2))
    else:
        run_gui()
