"""1つの出力を選び、他条件を固定して計算・反映する。"""
from dataclasses import replace
from design_modes import MODES,solve,validate_thermal_target

COUNT_MODE='必要管本数を求める（管長固定）'
UI_MODES=(MODES[0],COUNT_MODE,MODES[1],MODES[2])

def solve_and_apply(p,mode,target_side):
    if mode==COUNT_MODE:
        validate_thermal_target(p,target_side)
        skipped=0
        for n in range(1,2001):
            candidate=replace(p,tubes=float(n))
            try:resolved,r=solve(candidate,MODES[0],target_side)
            except ValueError:
                skipped+=1;continue
            if r['meets_design_area'] and r['results']['入力寸法の管内圧損 [kPa]']<=p.allowable_dp:
                r['mode']=mode
                r['design']={'length':resolved.length,'area':r['results']['入力寸法の面積 [m²]'],'hot_out':r['results']['入力寸法の高温出口 [°C]'],'cold_out':r['results']['入力寸法の低温出口 [°C]']}
                r['notes'].append(f'1～2000本を整数で評価し、面積余裕と入力許容管内圧損を満たす最小本数を選定。相関適用外等で除外した候補：{skipped}。')
                return resolved,r,{'tubes':resolved.tubes}
        raise ValueError('1～2000本の範囲では目標・面積余裕・管内許容圧損を満たす本数がありません。管長・径・流量・hoなどを見直してください。')
    if mode not in UI_MODES:raise ValueError('求める量を選択してください。')
    resolved,r=solve(p,mode,target_side)
    if mode==MODES[0]:
        length=r['design']['length']
        resolved,r=solve(replace(resolved,length=length),mode,target_side)
        return resolved,r,{'length':length}
    if mode==MODES[1]:
        field='hot_flow' if p.tube_cold else 'cold_flow'
        return resolved,r,{field:getattr(resolved,field)}
    return resolved,r,{'hot_target':r['results']['入力寸法の高温出口 [°C]'],'cold_target':r['results']['入力寸法の低温出口 [°C]']}
