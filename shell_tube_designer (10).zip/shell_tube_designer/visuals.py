"""温度グラフ・寸法概略図・熱抵抗イラスト。Matplotlib、Tkに依存しない描画。"""
import math
from matplotlib import rcParams, font_manager

def configure_japanese_font():
    """Windows/macOS/Linuxの日本語フォントを優先する。"""
    for path in font_manager.findSystemFonts():
        try:
            font_manager.fontManager.addfont(path)
        except (OSError, RuntimeError):
            pass
    available = {f.name for f in font_manager.fontManager.ttflist}
    preferred = ['Noto Sans CJK JP', 'Yu Gothic', 'Meiryo', 'Hiragino Sans', 'IPAexGothic']
    rcParams['font.family'] = [f for f in preferred if f in available] + ['DejaVu Sans']
    rcParams['axes.unicode_minus'] = False

configure_japanese_font()
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch

HOT, COLD = '#d35b43', '#287fa5'


def tube_layout(n, pitch_mm, do_mm, edge_mm=10.0):
    """直管の正方配列候補。仕切りなし、端部余裕は例示10mm。"""
    k = math.ceil(math.sqrt(n))
    pts = [(i*pitch_mm,j*pitch_mm) for i in range(-k,k+1) for j in range(-k,k+1)]
    pts.sort(key=lambda p:(p[0]**2+p[1]**2,p[1],p[0]))
    centers = pts[:n]
    r = max(math.hypot(x,y) for x,y in centers) + do_mm/2 + edge_mm
    minimum = math.ceil(2*r/5)*5  # 候補径を5mm刻みで切上げ
    return centers, minimum


def temperature_figure(p, result, compact=False):
    fig = Figure(figsize=(6.7,3.8) if compact else (10.8,6.4), dpi=100, facecolor='#f8fafc')
    r, d = result['results'], result['design']
    scenarios = [('入力した寸法 / Entered geometry',p.length,r['入力寸法の高温出口 [°C]'],r['入力寸法の低温出口 [°C]']),
                 ('目標から求めた寸法（面積余裕込み）',d['length'],d['hot_out'],d['cold_out'])]
    if result.get('mode') in ('シェル側媒体流量を求める','出口温度・交換熱量を求める'):
        scenarios[1]=('入力寸法（解いた流量での性能）',p.length,r['入力寸法の高温出口 [°C]'],r['入力寸法の低温出口 [°C]'])
    if compact:scenarios=[('反映後の寸法での入口・出口温度',p.length,r['入力寸法の高温出口 [°C]'],r['入力寸法の低温出口 [°C]'])]
    for i,(name,length,ho,co) in enumerate(scenarios):
        ax = fig.add_subplot(1,len(scenarios),i+1)
        ax.set_facecolor('white')
        ax.plot([0,1],[ho,p.hot_in] if p.tube_cold else [p.hot_in,ho],'-o',color=HOT,lw=2.5,label='高温側・シェル ←' if p.tube_cold else '高温側・管内 →')
        ax.plot([0,1],[p.cold_in,co] if p.tube_cold else [co,p.cold_in],'-o',color=COLD,lw=2.5,label='低温側・管内 →' if p.tube_cold else '低温側・シェル ←')
        if result.get('mode')!='出口温度・交換熱量を求める':
            cold_target=result.get('target_side','').startswith('低温')
            ax.axhline(p.cold_target if cold_target else p.hot_target,color=COLD if cold_target else HOT,ls='--',alpha=.7,label='低温出口の加熱目標' if cold_target else '高温出口の目標温度')
        for x,y,offset in [(1 if p.tube_cold else 0,p.hot_in,10),(0 if p.tube_cold else 1,ho,10),(0 if p.tube_cold else 1,p.cold_in,10),(1 if p.tube_cold else 0,co,-18 if abs(ho-co)<8 else 10)]:
            ax.annotate(f'{y:.2f} °C',(x,y),xytext=(0,offset),textcoords='offset points',ha='center',fontsize=10)
        ax.set_xticks([0,1],['左端\n低温入口 / 高温出口','右端\n低温出口 / 高温入口'] if p.tube_cold else ['左端\n高温入口 / 低温出口','右端\n高温出口 / 低温入口'])
        ax.set_xlim(-.17,1.17)
        span = p.hot_in-p.cold_in
        ax.set_ylim(p.cold_in-.15*span,p.hot_in+.2*span)
        ax.set_ylabel('温度 / Temperature [°C]')
        ax.set_title(f'{name}\n有効管長 L = {length:.3f} m',fontsize=11)
        ax.grid(alpha=.2); ax.legend(loc='upper right',fontsize=8)
    if not compact:fig.suptitle('対向流：管内を加熱（低温側 左→右 ／ 高温側 右→左）' if p.tube_cold else '対向流：管内を冷却（高温側 左→右 ／ 低温側 右→左）',fontsize=15,fontweight='bold')
    fig.text(.5,.02 if compact else .04,'線は端部温度の比較です。内部温度分布ではありません。' if compact else '直線は入口・出口を結ぶ比較用の線です。内部の局所温度分布を示すものではありません。',ha='center',fontsize=8 if compact else 10,color='#475569')
    fig.subplots_adjust(top=.84 if compact else .8,bottom=.22 if compact else .15,left=.12 if compact else .08,right=.97,wspace=.28)
    return fig


def dim(ax,start,end,label,offset=(0,0)):
    a=(start[0]+offset[0],start[1]+offset[1]); b=(end[0]+offset[0],end[1]+offset[1])
    for p,q in [(start,a),(end,b)]:
        ax.plot([p[0],q[0]],[p[1],q[1]],color='#718096',lw=.8)
    ax.annotate('',xy=a,xytext=b,arrowprops=dict(arrowstyle='<->',color='#334155',lw=1))
    ax.text((a[0]+b[0])/2,(a[1]+b[1])/2,label,ha='center',va='center',fontsize=9,
            bbox=dict(facecolor='white',edgecolor='none',pad=2))


def dimension_figure(p,result):
    fig = Figure(figsize=(11,7.5), dpi=100, facecolor='#f8fafc')
    centers, dmin = tube_layout(int(p.tubes),p.pitch_mm,p.outer_mm)
    ds = max(p.shell_mm,dmin)
    d = result['design']
    ax = fig.add_axes([.04,.33,.57,.53]); ax.set_xlim(-.6,8.2); ax.set_ylim(-.8,3.7); ax.axis('off')
    ax.add_patch(Rectangle((.6,.4),6,2,facecolor='#e6f2f8',edgecolor='#334155',lw=2))
    for x in [.85,6.35]:
        ax.plot([x,x],[.4,2.4],color='#64748b',lw=4)
    tube_color=COLD if p.tube_cold else HOT
    shell_color=HOT if p.tube_cold else COLD
    for y in [.95,1.9]:
        ax.plot([.85,6.35],[y,y],color=tube_color,lw=5)
    for y in [.95,1.9]:
        ax.annotate('',xy=(7.5,y),xytext=(-.2,y),arrowprops=dict(arrowstyle='->',color=tube_color,lw=2))
    tube_in=p.cold_in if p.tube_cold else p.hot_in
    tube_out=d['cold_out'] if p.tube_cold else d['hot_out']
    shell_in=p.hot_in if p.tube_cold else p.cold_in
    shell_out=d['hot_out'] if p.tube_cold else d['cold_out']
    ax.text(-.3,2.13,f'管内入口 / In\n{tube_in:.1f} °C',fontsize=9,color=tube_color)
    ax.text(6.8,2.13,f'管内出口 / Out\n{tube_out:.1f} °C',fontsize=9,color=tube_color)
    ax.annotate('',xy=(-.2,1.45),xytext=(7.5,1.45),arrowprops=dict(arrowstyle='->',color=shell_color,lw=2))
    ax.text(6.8,.05,f'媒体入口 / In\n{shell_in:.1f} °C',fontsize=9,color=shell_color)
    ax.text(-.3,.05,f'媒体出口 / Out\n{shell_out:.1f} °C',fontsize=9,color=shell_color)
    dim(ax,(.85,2.4),(6.35,2.4),f'有効管長 L = {d["length"]*1000:.1f} mm',offset=(0,.45))
    dim(ax,(6.6,.4),(6.6,2.4),f'シェル内径\nID {ds:.0f} mm',offset=(.85,0))
    ax.set_title('側面図：直管・1管パス・対向流（縮尺なし）',fontsize=10)
    cross = fig.add_axes([.68,.36,.28,.48]); cross.set_aspect('equal'); cross.axis('off')
    cross.add_patch(Circle((0,0),ds/2,facecolor='#e6f2f8',edgecolor='#334155',lw=2))
    for x,y in centers:
        cross.add_patch(Circle((x,y),p.outer_mm/2,facecolor='#a0d3e5' if p.tube_cold else '#f5ad91',edgecolor=tube_color,lw=.5))
    cross.text(0,ds*.6,f'並列直管 {int(p.tubes)} 本 / Straight tubes',ha='center',fontsize=10)
    cross.text(0,-ds*.62,f'管外径 OD {p.outer_mm:g} / 内径 ID {p.inner_mm:g} mm\n正方配列ピッチ {p.pitch_mm:g} mm',ha='center',fontsize=9)
    cross.set_xlim(-ds*.7,ds*.7); cross.set_ylim(-ds*.75,ds*.75)
    r=result['results']
    text=(f'目標（または性能計算の出口）：高温出口 {p.hot_target:.2f} °C  |  交換熱量 {r["目標交換熱量 [kW]"]:.2f} kW\n'
          f'固定条件：{int(p.tubes)} 本、管外径/内径 {p.outer_mm:g}/{p.inner_mm:g} mm、1管パス\n'
          f'設計寸法：有効管長 L {d["length"]:.4f} m、管外伝熱面積 {d["area"]:.4f} m²、面積余裕 {p.margin:g}%\n'
          f'シェル内径候補： {ds:.0f} mm （入力 {p.shell_mm:g} / 配列からの最小候補 {dmin:.0f} mm）\n'
          f'余裕込みの予測出口：高温側 {d["hot_out"]:.2f} °C / 低温側 {d["cold_out"]:.2f} °C')
    if result.get('target_side','').startswith('低温') and result.get('mode')!='出口温度・交換熱量を求める':
        text=f'加熱目標：低温出口 {p.cold_target:.2f} °C\n'+text
    fig.text(.06,.27,text,fontsize=10,va='top',linespacing=1.6)
    fig.text(.06,.055,'熱設計の概略図：胴全長・胴厚・ノズル・バッフル・管板厚は未設計です。\n管配列は端部余裕10 mmを仮定。支持棒・機械設計上の隙間は含みません。',fontsize=9,color='#475569')
    title='目標温度から求める寸法概略図 / Dimensions' if result.get('mode','伝熱面積・管長を求める')=='伝熱面積・管長を求める' else '固定した入力寸法と計算結果 / Dimensions'
    if result.get('stage')=='refined':title='② 推算Uで必要な寸法（候補寸法は結果欄）'
    fig.suptitle(title,fontsize=16,fontweight='bold',y=.96)
    return fig


def resistance_figure(tube_cold=False):
    fig=Figure(figsize=(11,4.6),dpi=130,facecolor='#f8fafc')
    ax=fig.add_axes([.03,.17,.94,.68]); ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,3)
    labels=['① 管内対流 / Tube\ndo / (di hi)','② 管内汚れ / Fouling\n(do/di) Rf,i','③ 管壁伝導 / Wall\ndo ln(do/di) / (2 kw)','④ 管外汚れ / Fouling\nRf,o','⑤ シェル側対流\n1 / ho']
    colors=['#f8b39c','#dfb58a','#94a3b8','#bad1ac','#a0d3e5']
    for i,(label,color) in enumerate(zip(labels,colors)):
        ax.add_patch(Rectangle((i*1.8+.5,.6),1.7,1.65,facecolor=color,edgecolor='white',lw=2))
        ax.text(i*1.8+1.35,1.9,label,ha='center',va='center',fontsize=9)
    ax.annotate('',xy=(.2,1) if tube_cold else (9.4,1),xytext=(9.4,1) if tube_cold else (.2,1),arrowprops=dict(arrowstyle='->',color='#9b302b',lw=4))
    ax.text(.2,2.6,'低温流体（管内） / COLD' if tube_cold else '高温流体（管内） / HOT',color=COLD if tube_cold else HOT,fontsize=12)
    ax.text(9.6,2.6,'加熱媒体（シェル側） / HOT' if tube_cold else '冷却媒体（シェル側） / COLD',color=HOT if tube_cold else COLD,fontsize=12,ha='right')
    fig.suptitle('熱の流れ：5つの直列熱抵抗 / Thermal resistances',fontsize=16,fontweight='bold')
    fig.text(.5,.08,'Uoは管外面積基準。管内側は径比 do/di で換算します。式と出典：heat_transfer.py / 式の参照サイト.md',ha='center',fontsize=10)
    return fig
