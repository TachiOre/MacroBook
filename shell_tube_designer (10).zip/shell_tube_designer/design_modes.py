"""GUIから独立した計算モードと流量単位変換。
対向流式の参照：https://ht.readthedocs.io/en/stable/ht.hx.html
流量換算は質量保存 m=ρV、1 L=10^-3 m³、1 min=60 s。
"""
from dataclasses import replace
import math
from heat_transfer import effectiveness, outer_area

MODES = ('伝熱面積・管長を求める', 'シェル側媒体流量を求める', '出口温度・交換熱量を求める', '① 仮定Uで必要面積を求める', '② 寸法からUを再計算する')
TARGETS = ('高温側の出口温度', '低温側の出口温度（加熱目標）')

def convert_flow(value, source, destination, density):
    if not math.isfinite(value) or value < 0 or not math.isfinite(density) or density <= 0:
        raise ValueError('流量は0以上、密度は正の有限値が必要です。')
    if source not in ('kg/s','L/min') or destination not in ('kg/s','L/min'):
        raise ValueError('対応単位：kg/s、L/min')
    mass = value if source == 'kg/s' else value*density/60000
    return mass if destination == 'kg/s' else mass*60000/density

def validate_thermal_target(p,target_side):
    """寸法計算前に熱収支・有限面積での目標達成可能性を確認。"""
    keys=('hot_in','cold_in','hot_flow','cold_flow','hot_cp','cold_cp','cold_target' if target_side==TARGETS[1] else 'hot_target')
    if any(not math.isfinite(getattr(p,k)) for k in keys):raise ValueError('温度・流量・比熱には有限値を入力してください。')
    if min(p.hot_flow,p.cold_flow,p.hot_cp,p.cold_cp)<=0:raise ValueError('両側の流量と比熱は正の値が必要です。')
    if p.hot_in<=p.cold_in:raise ValueError('高温側入口は低温側入口より高くしてください。')
    chosen=p.cold_target if target_side==TARGETS[1] else p.hot_target
    if not p.cold_in<chosen<p.hot_in:
        label='低温側の加熱目標出口' if target_side==TARGETS[1] else '高温側の冷却目標出口'
        raise ValueError(f'{label}={chosen:g}℃は、低温入口{p.cold_in:g}℃と高温入口{p.hot_in:g}℃の間に設定してください。目標温度を指定する側も確認してください。')
    ch=p.hot_flow*p.hot_cp;cc=p.cold_flow*p.cold_cp
    q=cc*(p.cold_target-p.cold_in) if target_side==TARGETS[1] else ch*(p.hot_in-p.hot_target)
    maxq=min(ch,cc)*(p.hot_in-p.cold_in)
    ho=p.hot_in-q/ch;co=p.cold_in+q/cc
    eps=q/maxq
    if eps>=1:
        if target_side==TARGETS[1]:
            minimum=q/(p.hot_cp*(p.hot_in-p.cold_in))
            limit=p.cold_in+maxq/cc
            raise ValueError(f'加熱目標を有限面積では達成できません。必要熱量{q/1000:.3f} kW、理論最大{maxq/1000:.3f} kW、目標ε={eps:.4f}。'
                f'熱収支から算出した高温側出口は{ho:.3f}℃（入力値ではありません）、低温入口は{p.cold_in:g}℃です。'
                f'この入口温度では高温側流量を{minimum:.6g} kg/sより大きくする必要があります。'
                f'現在の条件の低温側出口理論上限は{limit:.3f}℃です。媒体流量・入口温度・加熱目標を見直してください。')
        raise ValueError(f'冷却目標を有限面積では達成できません。必要熱量{q/1000:.3f} kW、理論最大{maxq/1000:.3f} kW、目標ε={eps:.4f}。熱収支から算出した低温側出口は{co:.3f}℃です。流量・入口温度・冷却目標を見直してください。')
    return q,ho,co


def solve(p, mode=MODES[0], target_side=TARGETS[0]):
    """入力データを変更せず、解決済みInputsと共通形式の結果を返す。"""
    from designer import calculate
    if mode=='冷却水量を求める':mode=MODES[1]
    if mode not in MODES or target_side not in TARGETS:
        raise ValueError('計算モード・目標側が不正です。')
    if mode in MODES[3:]:
        from staged_design import staged_solve
        return staged_solve(p,mode,target_side)
    if p.cold_rho <= 0 or not math.isfinite(p.cold_rho):
        raise ValueError('冷却水密度は正の有限値が必要です。')
    def rating(x):
        # 必要面積逆算を成立させる小さな仮目標で係数を取得。
        ch=x.hot_flow*x.hot_cp;cc=x.cold_flow*x.cold_cp
        t=x.hot_in-.01*min(ch,cc)*(x.hot_in-x.cold_in)/ch
        seed=calculate(replace(x,hot_target=t,margin=0))
        u=seed['results']['外面基準Uo [W/(m² K)]']
        q=effectiveness(u*outer_area(int(x.tubes),x.outer_mm/1000,x.length)/min(ch,cc),min(ch,cc)/max(ch,cc))*min(ch,cc)*(x.hot_in-x.cold_in)
        return q, u
    resolved=p
    if mode==MODES[0]:
        _,hot_out,_=validate_thermal_target(p,target_side)
        if target_side==TARGETS[1]:
            if not p.cold_in < p.cold_target < p.hot_in:
                raise ValueError('低温入口 < 加熱目標出口 < 高温入口 が必要です。')
            q=p.cold_flow*p.cold_cp*(p.cold_target-p.cold_in)
            resolved=replace(p,hot_target=hot_out)
        result=calculate(resolved)
    elif mode==MODES[1]:
        if not p.cold_in < (p.hot_target if target_side==TARGETS[0] else p.cold_target) < p.hot_in:
            raise ValueError('目標出口は低温入口と高温入口の間にしてください。')
        # シェル側流量を出力。加熱時は高温媒体流量を解く。
        field='hot_flow' if p.tube_cold else 'cold_flow'
        probe=replace(p,**{field:1.0})
        _,u=rating(probe)
        ua=u*outer_area(int(p.tubes),p.outer_mm/1000,p.length)
        if not p.tube_cold and target_side==TARGETS[0]:
            ch=p.hot_flow*p.hot_cp;dt=p.hot_in-p.cold_in
            qlimit=ch*dt*(-math.expm1(-ua/ch))
            if ch*(p.hot_in-p.hot_target)>=qlimit*(1-1e-12):
                raise ValueError('指定寸法では冷却水量を増やしても目標を達成できません。伝熱面積を増やしてください。')
        def residual(m):
            x=replace(p,**{field:m})
            ch=x.hot_flow*x.hot_cp;cc=x.cold_flow*x.cold_cp;cmin=min(ch,cc)
            q=effectiveness(ua/cmin,cmin/max(ch,cc))*cmin*(x.hot_in-x.cold_in)
            return x.hot_in-q/ch-p.hot_target if target_side==TARGETS[0] else x.cold_in+q/cc-p.cold_target
        lo=1e-10;hi=1.0
        for _ in range(80):
            if residual(lo)*residual(hi)<=0:break
            hi*=2
        else:raise ValueError('指定寸法とhoでは媒体流量の有限解がありません。面積・目標温度を見直してください。')
        for _ in range(120):
            mid=(lo+hi)/2
            if residual(lo)*residual(mid)<=0:hi=mid
            else:lo=mid
        solved=replace(p,**{field:(lo+hi)/2})
        q,_=rating(solved)
        resolved=replace(solved,hot_target=p.hot_in-q/(solved.hot_flow*p.hot_cp),margin=0)
        result=calculate(resolved)
        result['notes'].append('媒体流量逆算：寸法を固定。シェル側hoを流量によらず固定した条件付きの解です。')
    else:
        q,_=rating(p)
        resolved=replace(p,hot_target=p.hot_in-q/(p.hot_flow*p.hot_cp),margin=0)
        result=calculate(resolved)
        result['notes'].append('性能計算：入口条件・流量・入力寸法から出口を求めます。目標温度と面積余裕率は不使用。')
    result['mode']=mode;result['target_side']=target_side
    result['results'].update({'高温側流量 [kg/s]':resolved.hot_flow,'高温側流量 [L/min]':convert_flow(resolved.hot_flow,'kg/s','L/min',resolved.hot_rho), '低温側流量 [kg/s]':resolved.cold_flow,'低温側流量 [L/min]':convert_flow(resolved.cold_flow,'kg/s','L/min',resolved.cold_rho)})
    return resolved,result
