import unittest
from dataclasses import replace
from io import BytesIO
from designer import Inputs
from design_modes import MODES,TARGETS,solve
from staged_visuals import preliminary_figures
from visuals import temperature_figure,dimension_figure,resistance_figure

class StagedTests(unittest.TestCase):
    def test_no_geometry_in_first_stage(self):
        p=replace(Inputs(),tubes=-1,length=-1,outer_mm=-1,inner_mm=-1,shell_h=-1)
        _,r=solve(p,MODES[3])
        self.assertAlmostEqual(r['preliminary']['area'],83_600/(600*r['preliminary']['lmtd']))
    def test_u_inverse_scaling(self):
        _,a=solve(Inputs(),MODES[3]);_,b=solve(replace(Inputs(),assumed_u=1200),MODES[3])
        self.assertAlmostEqual(a['preliminary']['area'],2*b['preliminary']['area'])
    def test_length_candidate(self):
        p,r=solve(Inputs(),MODES[4])
        self.assertAlmostEqual(p.tubes*3.141592653589793*.019*p.length,r['preliminary']['design_area'])
        self.assertNotAlmostEqual(r['results']['仮定Uo [W/(m² K)]'],r['results']['外面基準Uo [W/(m² K)]'])
    def test_number_candidate_rounds_up(self):
        p,r=solve(replace(Inputs(),geometry_choice=1),MODES[4])
        self.assertGreaterEqual(p.tubes*3.141592653589793*.019*p.length,r['preliminary']['design_area'])
        self.assertLess((p.tubes-1)*3.141592653589793*.019*p.length,r['preliminary']['design_area'])
    def test_heating_tube_properties(self):
        p=replace(Inputs(),tube_cold=1,margin=0)
        resolved,r=solve(p,MODES[4],TARGETS[1])
        self.assertAlmostEqual(r['results']['管内Pr [-]'],p.cold_cp*p.cold_mu/p.cold_k)
        self.assertAlmostEqual(r['design']['cold_out'],p.cold_target,places=8)
    def test_refined_length_reaches_target(self):
        p,r=solve(replace(Inputs(),margin=0),MODES[4])
        _,rated=solve(replace(p,length=r['design']['length']),MODES[2])
        self.assertAlmostEqual(rated['results']['入力寸法の高温出口 [°C]'],p.hot_target,places=8)
    def test_heating_media_flow_recovers(self):
        base=replace(Inputs(),tube_cold=1)
        _,r=solve(base,MODES[2])
        p,_=solve(replace(base,cold_target=r['results']['入力寸法の低温出口 [°C]']),MODES[1],TARGETS[1])
        self.assertAlmostEqual(p.hot_flow,base.hot_flow,places=8)
    def test_all_stage_figures(self):
        for heating in (0,1):
            p=replace(Inputs(),tube_cold=heating)
            side=TARGETS[heating]
            p,r=solve(p,MODES[3],side)
            figs=list(preliminary_figures(p,r))
            p,r=solve(p,MODES[4],side)
            figs.extend([temperature_figure(p,r),dimension_figure(p,r),resistance_figure(bool(heating))])
            if heating:
                self.assertEqual(list(figs[2].axes[0].lines[0].get_ydata()),[r['results']['入力寸法の高温出口 [°C]'],p.hot_in])
            for f in figs:
                buf=BytesIO();f.savefig(buf,format='png');self.assertGreater(len(buf.getvalue()),10000)

if __name__=='__main__':unittest.main()
