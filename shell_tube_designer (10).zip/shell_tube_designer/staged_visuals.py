"""寸法が未定の仮定U段階の図。日本語フォント設定はvisualsを共用。"""
from matplotlib.figure import Figure
from visuals import HOT,COLD

def preliminary_figures(p,r):
    b=r['preliminary']
    temp=Figure(figsize=(10.8,6.4),facecolor='#f8fafc');ax=temp.add_subplot(111)
    ax.plot([0,1],[b['hot_out'],p.hot_in] if p.tube_cold else [p.hot_in,b['hot_out']],'-o',color=HOT,label='高温側')
    ax.plot([0,1],[p.cold_in,b['cold_out']] if p.tube_cold else [b['cold_out'],p.cold_in],'-o',color=COLD,label='低温側')
    ax.set_xticks([0,1],['低温入口 / 高温出口','低温出口 / 高温入口'] if p.tube_cold else ['高温入口 / 低温出口','高温出口 / 低温入口'])
    ax.set_ylabel('温度 [℃]');ax.legend();ax.grid(alpha=.2)
    ax.set_title('① 目標温度の熱収支（寸法未定）')
    for x,y in [(1 if p.tube_cold else 0,p.hot_in),(0 if p.tube_cold else 1,b['hot_out']),(1 if p.tube_cold else 0,b['cold_out']),(0 if p.tube_cold else 1,p.cold_in)]:ax.annotate(f'{y:.2f} ℃',(x,y),xytext=(0,10),textcoords='offset points',ha='center')
    temp.text(.5,.025,'端部温度の比較です。内部温度分布ではありません。',ha='center');temp.subplots_adjust(bottom=.15)
    area=Figure(figsize=(11,7.5),facecolor='#f8fafc')
    area.suptitle('① 仮定Uによる必要伝熱面積',fontsize=20,y=.9)
    area.text(.1,.69,f'必要面積（余裕なし） {b["area"]:.4f} m²\n設計面積（余裕{p.margin:g}%） {b["design_area"]:.4f} m²',fontsize=22,linespacing=1.8)
    area.text(.1,.46,f'仮定Uo：{p.assumed_u:g} W/(m² K)\n目標熱量：{b["q"]/1000:.3f} kW ／ LMTD：{b["lmtd"]:.3f} K\nAo = Q / (Uo × LMTD)',fontsize=15,linespacing=1.8)
    area.text(.1,.22,'②へ切り替えて管径と本数または管長を指定します。\n候補寸法でU・出口温度・圧力損失を再評価し、\n推算Uによる必要面積・必要管長を確認してください。',fontsize=14,linespacing=1.8)
    area.text(.1,.08,'この段階では寸法を使いません。仮定Uの面積だけでは目標性能を保証しません。',fontsize=11)
    return temp,area
