import unittest
import math
from io import BytesIO
from dataclasses import replace
from designer import Inputs,calculate
from visuals import tube_layout,temperature_figure,dimension_figure,resistance_figure

class DrawingTests(unittest.TestCase):
    def test_tube_layout(self):
        for n in [1,3,39,40,200,2000]:
            pts,diameter=tube_layout(n,25,19)
            self.assertEqual(len(pts),n)
            self.assertTrue(all(math.hypot(x,y)+19/2+10 <= diameter/2 for x,y in pts))
            self.assertEqual(len(set(pts)),n)
    def test_render_figures(self):
        p=Inputs();r=calculate(p)
        for fig in [temperature_figure(p,r),dimension_figure(p,r),resistance_figure()]:
            buffer=BytesIO();fig.savefig(buffer,format='png')
            self.assertGreater(len(buffer.getvalue()),10000)
    def test_graph_endpoint_values(self):
        p=Inputs();r=calculate(p);fig=temperature_figure(p,r)
        self.assertAlmostEqual(fig.axes[0].lines[0].get_ydata()[1],r['results']['入力寸法の高温出口 [°C]'])
        self.assertAlmostEqual(fig.axes[1].lines[0].get_ydata()[1],r['design']['hot_out'])
    def test_cold_flow_opposes_hot(self):
        p=Inputs();r=calculate(p);fig=temperature_figure(p,r)
        self.assertEqual(list(fig.axes[0].lines[1].get_ydata()),[r['results']['入力寸法の低温出口 [°C]'],p.cold_in])
    def test_zero_margin_outlet_matches_target(self):
        p=replace(Inputs(),margin=0)
        self.assertAlmostEqual(calculate(p)['design']['hot_out'],p.hot_target,places=8)
    def test_sizing_shortens_with_smaller_duty(self):
        base=calculate(Inputs())['design']['length']
        shorter=calculate(replace(Inputs(),hot_target=70))['design']['length']
        self.assertLess(shorter,base)

if __name__=='__main__':unittest.main()
