"""仮定Uの面積設計→寸法候補→相関式Uの再評価。
式の出典：ASHRAE Chapter 4 Heat Exchangers、ht.hx NTU_from_effectiveness。
https://ht.readthedocs.io/en/stable/ht.hx.html#ht.hx.NTU_from_effectiveness
"""
import math
from dataclasses import replace
from heat_transfer import required_ntu,lmtd,required_length

def preliminary(p,target_side):
    from design_modes import TARGETS
    keys=('hot_in','cold_in','hot_flow','cold_flow','hot_cp','cold_cp','hot_target' if target_side==TARGETS[0] else 'cold_target','assumed_u','margin')
    if any(not math.isfinite(getattr(p,k)) for k in keys):raise ValueError('温度・流量・Uには有限値を入力してください。')
    if min(p.hot_flow,p.cold_flow,p.hot_cp,p.cold_cp,p.assumed_u)<=0 or p.margin<0:raise ValueError('流量・比熱・仮定Uは正、余裕率は0以上が必要です。')
    if p.hot_in<=p.cold_in:raise ValueError('高温側入口は低温側入口より高くしてください。')
    ch=p.hot_flow*p.hot_cp;cc=p.cold_flow*p.cold_cp
    q=ch*(p.hot_in-p.hot_target) if target_side==TARGETS[0] else cc*(p.cold_target-p.cold_in)
    cmin=min(ch,cc);eps=q/(cmin*(p.hot_in-p.cold_in))
    ntu=required_ntu(eps,cmin/max(ch,cc))
    ho=p.hot_in-q/ch;co=p.cold_in+q/cc
    delta=lmtd(p.hot_in-co,ho-p.cold_in)
    area=ntu*cmin/p.assumed_u
    return {'q':q,'hot_out':ho,'cold_out':co,'area':area,'design_area':area*(1+p.margin/100),'lmtd':delta,'ntu':ntu}

def staged_solve(p,mode,target_side):
    from design_modes import solve,MODES
    base=preliminary(p,target_side)
    if mode==MODES[3]:
        r={'mode':mode,'target_side':target_side,'stage':'preliminary',
           'results':{'目標交換熱量 [kW]':base['q']/1000,'仮定Uo [W/(m² K)]':p.assumed_u,'目標時 LMTD [K]':base['lmtd'],'仮定Uの必要面積（余裕なし） [m²]':base['area'],'仮定Uの設計面積（余裕込み） [m²]':base['design_area'],'目標高温出口 [°C]':base['hot_out'],'目標低温出口 [°C]':base['cold_out']},
           'resistance':{},'notes':['①は寸法不要。仮定Uは管外面積基準です。②で管内相関式からUを再評価してください。'],
           'preliminary':base,'meets_target':False,'meets_design_area':False}
        return p,r
    candidate=p
    if p.geometry_choice==0:
        if p.tubes!=int(p.tubes) or not 1<=p.tubes<=2000 or p.outer_mm<=0:raise ValueError('候補管本数は1～2000の整数、外径は正にしてください。')
        candidate=replace(p,length=required_length(base['design_area'],int(p.tubes),p.outer_mm/1000))
    elif p.geometry_choice==1:
        if p.length<=0 or p.outer_mm<=0:raise ValueError('候補管長・外径は正にしてください。')
        candidate=replace(p,tubes=math.ceil(base['design_area']/(math.pi*p.outer_mm/1000*p.length)))
    elif p.geometry_choice!=2:raise ValueError('寸法候補の決め方が不正です。')
    solved,r=solve(candidate,MODES[0],target_side)
    r.update(mode=mode,stage='refined',preliminary=base)
    r['results'].update({'仮定Uo [W/(m² K)]':p.assumed_u,'仮定Uの設計面積（余裕込み） [m²]':base['design_area'],'候補管本数 [本]':solved.tubes,'候補有効管長 [m]':solved.length,'U推算値/仮定値 [-]':r['results']['外面基準Uo [W/(m² K)]']/p.assumed_u})
    r['notes'].append('②のUは管内相関式＋入力hoによる推算値。寸法候補の性能と、推算Uで必要な面積・管長を比較表示します。')
    return solved,r
