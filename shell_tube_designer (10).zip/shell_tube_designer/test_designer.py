import math
import unittest
from dataclasses import replace
from designer import Inputs, calculate, effectiveness, required_ntu, lmtd

class PhysicsTests(unittest.TestCase):
    def test_energy_balance(self):
        p = Inputs()
        r = calculate(p)['results']
        qh = p.hot_flow*p.hot_cp*(p.hot_in-r['入力寸法の高温出口 [°C]'])
        qc = p.cold_flow*p.cold_cp*(r['入力寸法の低温出口 [°C]']-p.cold_in)
        self.assertAlmostEqual(qh,qc,places=8)
    def test_inverse(self):
        for cr in [0,0.1,0.9,1]:
            for ntu in [0.001,0.1,1,5]:
                self.assertAlmostEqual(required_ntu(effectiveness(ntu,cr),cr),ntu,places=8)
    def test_single_pass_velocity_and_pressure_drop(self):
        from heat_transfer import tube_velocity, tube_pressure_drop
        self.assertAlmostEqual(tube_velocity(1,1000,.01,5),1/(1000*5*math.pi*.01**2/4))
        self.assertAlmostEqual(tube_pressure_drop(.02,2,.01,1000,1,0),2000)
    def test_counterflow_lmtd_and_odd_tubes(self):
        r=calculate(replace(Inputs(),tubes=39))['results']
        self.assertAlmostEqual(r['目標時 補正係数F [-]'],1,places=12)
        self.assertAlmostEqual(required_ntu(.5,1),1)
        self.assertAlmostEqual(effectiveness(1,1),.5)
        calculate(replace(Inputs(),hot_target=21))
    def test_equal_terminal_differences(self):
        self.assertEqual(lmtd(40,40),40)
    def test_target_length_reproduces_duty(self):
        p = replace(Inputs(),margin=0)
        r = calculate(p)['results']
        rr = calculate(replace(p,length=r['必要有効管長（余裕込み） [m]']))['results']
        self.assertAlmostEqual(rr['入力寸法の高温出口 [°C]'],p.hot_target,places=8)
    def test_more_fouling_less_heat(self):
        q = lambda p:calculate(p)['results']['入力寸法の交換熱量 [kW]']
        self.assertLess(q(replace(Inputs(),fouling_o=0.001)),q(Inputs()))
    def test_impossible_target(self):
        with self.assertRaises(ValueError):
            calculate(replace(Inputs(),hot_target=21,cold_flow=0.5))
    def test_invalid_inputs(self):
        for change in [dict(tubes=3.5),dict(inner_mm=20),dict(hot_flow=-1),dict(hot_in=float('nan'))]:
            with self.assertRaises(ValueError):
                calculate(replace(Inputs(),**change))
    def test_laminar(self):
        r = calculate(replace(Inputs(),hot_flow=0.05))['results']
        self.assertEqual(r['管内Nu [-]'],3.66)
    def test_equal_capacity_rates(self):
        r = calculate(replace(Inputs(),cold_flow=1))['results']
        self.assertTrue(math.isfinite(r['必要有効管長（余裕込み） [m]']))
    def test_transition_rejected(self):
        with self.assertRaises(ValueError):
            calculate(replace(Inputs(),hot_flow=0.54))
    def test_effectiveness_bound(self):
        for cr in [0,0.5,1]:
            self.assertLessEqual(effectiveness(1000,cr),1.0)

if __name__ == '__main__':
    unittest.main()
